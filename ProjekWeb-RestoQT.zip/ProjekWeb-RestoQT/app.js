const express = require('express')
const app = express()
const port = process.env.PORT || 3000

require('./utils/db')
const order = require('./models/Order')
const saran = require('./models/Saran')

app.set('view engine', 'ejs')
app.use(express.static('public'))
app.use(express.urlencoded({ extended: true }))


app.get('/', (req, res) => {
    res.render('index')
})

app.post('/order', (req, res) => {
    const nama = req.body.nama
    const noTelp = req.body.noTelp
    const alamat = req.body.alamat
    const makanan = req.body.makanan
    const jumlah_makanan = req.body.jumlah_makanan
    const minuman = req.body.minuman
    const jumlah_minuman = req.body.jumlah_minuman
    const dessert = req.body.dessert
    const jumlah_dessert = req.body.jumlah_dessert
    const tanggal_pesan = req.body.tanggal_pesan


    const newOrder = new order({
        nama, noTelp, alamat, makanan, jumlah_makanan, minuman, jumlah_minuman, dessert, jumlah_dessert, tanggal_pesan
    })

    newOrder.save().then(() => res.redirect('/'))
})

app.post('/saran', (req, res) => {
    const contact_name = req.body.contact_name
    const contact_email = req.body.contact_email
    const contact_subject = req.body.contact_subject
    const contact_message = req.body.contact_message

    const newSaran = new saran({
        contact_name, contact_email, contact_subject, contact_message
    })

    newSaran.save().then(() => res.redirect('/'))
})


app.listen(port, () => {
    console.log(`Server is Running at http://localhost:${port}`)
})