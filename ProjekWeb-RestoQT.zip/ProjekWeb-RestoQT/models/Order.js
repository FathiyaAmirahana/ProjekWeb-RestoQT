const mongoose = require('mongoose')


const orderSchema = new mongoose.Schema({
    nama: String,
    noTelp: String,
    alamat: String,
    makanan: String,
    jumlah_makanan: String,
    minuman: String,
    jumlah_minuman: String,
    dessert: String,
    jumlah_dessert: String,
    tanggal_pesan: Date
})


const order = mongoose.model('order', orderSchema)

module.exports = order