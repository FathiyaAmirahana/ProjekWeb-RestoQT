const mongoose = require('mongoose')


const saranSchema = new mongoose.Schema({
    contact_name : String,
    contact_email : String,
    contact_subject : String,
    contact_message : String
})

const saran = mongoose.model('saran', saranSchema)

module.exports = saran