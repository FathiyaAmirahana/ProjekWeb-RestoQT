const mongoose = require('mongoose')

mongoose.connect('mongodb+srv://restoqt1234:restoqt1234@cluster0.ncdql.mongodb.net/Database', {
    useCreateIndex: true,
    useNewUrlParser: true,
    useUnifiedTopology: true
})